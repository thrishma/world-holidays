import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='thrishma',
    application_name='world-holidays',
    app_uid='NXH2bWnMJ97v7ZG6FH',
    org_uid='11b02d18-917d-4c95-ae96-24d1948171dc',
    deployment_uid='69a12b64-e924-41d1-a331-96220e3ab7a9',
    service_name='world-holidays',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'holiday_fetcher', 'timeout': 900}
try:
    user_handler = serverless_sdk.get_user_handler('holiday_fetcher.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
