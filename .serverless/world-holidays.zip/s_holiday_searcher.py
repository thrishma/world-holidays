import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='thrishma',
    application_name='world-holidays',
    app_uid='NXH2bWnMJ97v7ZG6FH',
    org_uid='11b02d18-917d-4c95-ae96-24d1948171dc',
    deployment_uid='f9b89690-64b7-4c46-a6a5-8fd950c60f2a',
    service_name='world-holidays',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'world-holidays-dev-holiday_searcher', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('holidayFetcher.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
